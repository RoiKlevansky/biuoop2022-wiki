
/**
 * The main class for Task1.
 */
public class Task1 {
   /** The main method.
    *
    * @param args ignored
    */
   public static void main(String[] args) {
      System.out.println("Hello Task1");
   }
}
